# TODO

### Gameplay
- More boomstick
- Settings

### Misc
- Setup a Discord server
- Quit deleting stuff, lol
