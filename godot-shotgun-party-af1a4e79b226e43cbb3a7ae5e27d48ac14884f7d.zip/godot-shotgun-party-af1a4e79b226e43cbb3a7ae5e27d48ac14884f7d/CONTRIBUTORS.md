# Contributors
> Special thanks for all the people who had helped this project so far:
- Endre Johnsen
- [@kalethequick](https://twitter.com/kalethequick)
- Mr H
- Nick Ruiz Müller
- Patrick
- Terrence Conrad